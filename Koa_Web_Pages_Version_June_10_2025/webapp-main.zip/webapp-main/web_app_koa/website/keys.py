secert_key_intermedia = 'jTZM15gszLK7lDuLwrZjEmtjeMSzahNcEi7X6hSduUA'
client_id_intermedia = 'qeX1ZMotc0eIpWNvfYjRvQ'
